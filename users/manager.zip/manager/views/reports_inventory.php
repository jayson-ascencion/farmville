<?php
    //title of the pge
    $title = "Chicken Production";

    //header
    include("../../includes/header.php");
    
?>


        <div class="container-fluid px-4">
            
            <h1 class="mt-4"> Manager Dashboard</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item">
                    <a href="./index.php" style="text-decoration: none">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Feeds Inventory</li>
            </ol>
            <div class="wrapper mb-5">
                <div class="container">
                    <div class="row">
                        <div class="p-0">
                            <div class="card shadow-lg">
                                <div class="card-header rounded rounded-3"  style="background-color: #f37e57;">
                                    <!-- <div class="row">
                                        <div class="col col-sm-9">Sales Data</div>
                                        <div class="col col-sm-3">
                                            <input type="text" id="daterange_textbox" class="form-control" readonly />
                                        </div>
                                    </div> -->

                                    <div class="row justify-content-between">
                                        <div class="col-xl-6 col-md-6">
                                            <h4 class="pt-2 fs-5 fw-bold">Reports</h4>
                                        </div>

                                        <div class="col-xl-3 col-md-3 align-content-end">
                                            <div class="w-100 d-flex text-center  justify-content-end">
                                                <!-- <div class="m-1 w-100 float-end">
                                                    <a href="add_feeds_form.php" class="btn btn-success shadow-sm w-100 fw-bold">Add Feeds</a>style="width: 250px"
                                                </div> -->
                                                <input type="text" id="daterange_textbox" class="form-control bg-success text-center"  readonly/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            <!-- MEDICINES -->
                            <div class="card mt-3 shadow-lg">
                                <div class="card-header fw-bold fs-5">
                                    Medicine Inventory
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive m-1">
                                        <h5 class="text-center" style="color: rgb(100, 100, 100)">Medicines Inventory Report</h5>
                                        <div class="chart-container bar-chart">
                                            <canvas id="bar_chart" height="100"> </canvas>
                                        </div>
                                        <table class="table responsive border table-hover text-center rounde rounded-3 overflow-hidden" style="width: 100%" id="medicine_table">
                                            <thead class="bg-dark text-white">
                                                <tr>
                                                    <th>Date Added</th>
                                                    <th>Medicine Name</th>
                                                    <th>Expiration Date</th>
                                                    <th>Starting Quantity</th>
                                                    <th>In Stock</th>
                                                    <th>Reductions</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>

                                        <hr class="border mt-5 border-dark border-3 opacity-75"> 

                                        <h5 class="text-center" style="color: rgb(100, 100, 100)">List of Medicines About To Expire</h5>
                                        <table class="table responsive border table-hover text-center rounde rounded-3 overflow-hidden" style="width: 100%" id="list_medicines">
                                            <thead class="bg-dark text-white">
                                                <tr>
                                                    <th>Date Added</th>
                                                    <th>Medicine Name</th>
                                                    <th>Expiration Date</th>
                                                    <th>Starting Quantity</th>
                                                    <th>In Stock</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>

                                        <hr class="border mt-5 border-dark border-3 opacity-75"> 

                                        <h5 class="text-center" style="color: rgb(100, 100, 100)">List of Medicines Low In Stock</h5>
                                        <table class="table responsive border table-hover text-center rounde rounded-3 overflow-hidden" style="width: 100%" id="low_stock">
                                            <thead class="bg-dark text-white">
                                                <tr>
                                                    <th>Date Added</th>
                                                    <th>Medicine Name</th>
                                                    <th>Expiration Date</th>
                                                    <th>Starting Quantity</th>
                                                    <th>In Stock</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- FEEDS -->
                            <div class="card mt-3 shadow-lg">
                                <div class="card-header fw-bold fs-5">
                                    Feed Inventory
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive m-1">
                                        <h5 class="text-center" style="color: rgb(100, 100, 100)">Feeds Report</h5>
                                        <div class="chart-container bar-chart">
                                            <canvas id="feed_chart" height="100"> </canvas>
                                        </div>
                                        <table class="table responsive border table-hover text-center rounde rounded-3 overflow-hidden" style="width: 100%" id="feed_table">
                                            <thead class="bg-dark text-white">
                                                <tr>
                                                    <th>Date Purchased</th>
                                                    <th>Feed Name</th>
                                                    <th>Starting Quantity</th>
                                                    <th>In Stock</th>
                                                    <th>Reductions</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>

<script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous" async defer></script>
<script src="../../../assets/js/jquery-3.6.1.min.js"></script>
<script src="../../../assets/js/bootstrap5.bundle.min.js" crossorigin="anonymous"></script>
<script src="../../../assets/js/scripts.js"></script>
<script src="../../../assets/js/moment.js"></script>
<script src="../../../assets/js/popper.min.js"></script>
<script src="../../../assets/js/datatables.min.js"></script>
<script src="../../../assets/js/daterangepicker.js"></script>
<script src="../../../assets/js/pdfmake.min.js"></script>
<script src="../../../assets/js/vfs_fonts.js"></script>
<script src="../../../assets/js/chart.js"></script>
<script src="../../../assets/js/chartjs-adapter-date-fns.bundle.min.js"></script>
<script>
    $.extend( $.fn.dataTable.defaults, {
        // "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
        // "lengthMenu": [[-1, 10, 25, 50, 100], ["All", 10, 25, 50, 100]],
        "pageLength": -1,
        responsive: true,
        stateSave: true,
        columnDefs: [
            {"className": "dt-center", "targets": "_all"} //center all text in the table
        ],
    });
    $(document).ready(function(){

    // fetch_data();

    var production_chart;
    var feed_chart;

    // var start = moment().format('YYYY-MM-DD');
    // var end = moment().format('YYYY-MM-DD');
    // // fetch_data();
    // fetch_data(moment().format('YYYY-MM-DD'), moment().format('YYYY-MM-DD'));

    // $('#daterange_textbox').data('daterangepicker').setStartDate(moment().format('YYYY-MM-DD'));
    // $('#daterange_textbox').data('daterangepicker').setEndDate(moment().format('YYYY-MM-DD'));
    // fetch_data();
    fetch_data(moment().format('YYYY-MM-DD'), moment().format('YYYY-MM-DD'));

    //function to fetch data
    function fetch_data(start_date = '', end_date = '')
    {
        //creates the table
        //production table
        var dataTable = $('#medicine_table').DataTable({
            "columnDefs": [
                {
                    "targets": [0,2],
                    "render": function (data, type, row) {
                        var date = new Date(data);
                        var options = {year: 'numeric', month: 'short', day: 'numeric' };
                        return date.toLocaleDateString('en-US', options);
                    },
                   
                },
                {
                    "className": "dt-center", "targets": "_all"
                }
            ],
            "processing" : true,
            "serverSide" : true, //serverside
            "order" : [], //enables table ordering
            "ajax" : {
                url:"../action/reports_action.php",
                type:"POST",
                data:{action:'medicine', start_date:start_date, end_date:end_date}
            },
            "drawCallback" : function(settings)
            {
                var dateAdded = [];
                var expirationDate = [];
                var instock = [];
                var reductions = [];
                var startingQuantity = [];
                var medicineName = [];

                for(var count = 0; count < settings.aoData.length; count++)
                {
                    //$order_column = array('dateAdded','medicineName','expirationDate','startingQuantity','instock','reductions');
                    var dA = new Date(settings.aoData[count]._aData[0]);
                    var eD = new Date(settings.aoData[count]._aData[2]);
                    var options = {year: 'numeric', month: 'short', day: 'numeric' };
                    dateAdded.push(dA.toLocaleDateString('en-US', options));
                    expirationDate.push(eD.toLocaleDateString('en-US', options));
                    // eggSize.push(settings.aoData[count]._aData[1]);
                    medicineName.push(settings.aoData[count]._aData[1]);
                    startingQuantity.push(parseFloat(settings.aoData[count]._aData[3]));
                    instock.push(parseFloat(settings.aoData[count]._aData[4]));
                    reductions.push(parseFloat(settings.aoData[count]._aData[5]));
                }
                console.log(dateAdded)
                var chart_data = {
                    labels:dateAdded,
                    datasets:[
                        {
                            label : 'Total Quantity',
                            backgroundColor : 'rgb(65,105,225)',
                            color : '#fff',
                            data:startingQuantity
                        },
                        {
                            label : 'Total In Stock',
                            backgroundColor : 'rgb(34, 139, 134)',
                            color : '#fff',
                            data:instock
                        },
                        {
                            label : 'Quantity Reduced',
                            backgroundColor : 'rgb(205,92,92)',
                            color : '#fff',
                            data:reductions
                        }
                    ]   
                };

                var group_chart3 = $('#bar_chart');

                if(production_chart)
                {
                    production_chart.destroy();
                }

                production_chart = new Chart(group_chart3, {
                    type:'bar',
                    data:chart_data,
                });
            }
        });

        //list of medicines
        var dataTable = $('#list_medicines').DataTable({
            "columnDefs": [
                {
                    "targets": [0,2],
                    "render": function (data, type, row) {
                        var date = new Date(data);
                        var options = {year: 'numeric', month: 'short', day: 'numeric' };
                        return date.toLocaleDateString('en-US', options);
                    },
                   
                },
                {
                    "className": "dt-center", "targets": "_all"
                }
            ],
            "processing" : true,
            "serverSide" : true, //serverside
            "order" : [], //enables table ordering
            "ajax" : {
                url:"../action/reports_action.php",
                type:"POST",
                data:{action:'toexpire', start_date:start_date, end_date:end_date}
            },
            // "drawCallback" : function(settings)
            // {
            //     var dateAdded = [];
            //     var expirationDate = [];
            //     var instock = [];
            //     var reductions = [];
            //     var startingQuantity = [];
            //     var medicineName = [];

            //     for(var count = 0; count < settings.aoData.length; count++)
            //     {
            //         //$order_column = array('dateAdded','medicineName','expirationDate','startingQuantity','instock','reductions');
            //         var dA = new Date(settings.aoData[count]._aData[0]);
            //         var eD = new Date(settings.aoData[count]._aData[2]);
            //         var options = {year: 'numeric', month: 'short', day: 'numeric' };
            //         dateAdded.push(dA.toLocaleDateString('en-US', options));
            //         expirationDate.push(eD.toLocaleDateString('en-US', options));
            //         // eggSize.push(settings.aoData[count]._aData[1]);
            //         medicineName.push(settings.aoData[count]._aData[1]);
            //         startingQuantity.push(parseFloat(settings.aoData[count]._aData[3]));
            //         instock.push(parseFloat(settings.aoData[count]._aData[4]));
            //         reductions.push(parseFloat(settings.aoData[count]._aData[5]));
            //     }
            //     console.log(dateAdded)
            //     // var chart_data = {
            //     //     labels:dateAdded,
            //     //     datasets:[
            //     //         {
            //     //             label : 'Total Quantity',
            //     //             backgroundColor : 'rgb(65,105,225)',
            //     //             color : '#fff',
            //     //             data:startingQuantity
            //     //         },
            //     //         {
            //     //             label : 'Total In Stock',
            //     //             backgroundColor : 'rgb(34, 139, 134)',
            //     //             color : '#fff',
            //     //             data:instock
            //     //         },
            //     //         {
            //     //             label : 'Quantity Reduced',
            //     //             backgroundColor : 'rgb(205,92,92)',
            //     //             color : '#fff',
            //     //             data:reductions
            //     //         }
            //     //     ]   
            //     // };

            //     // var group_chart3 = $('#bar_chart');

            //     // if(production_chart)
            //     // {
            //     //     production_chart.destroy();
            //     // }

            //     // production_chart = new Chart(group_chart3, {
            //     //     type:'bar',
            //     //     data:chart_data,
            //     // });
            // }
        });

        //low stock of medicines
        var dataTable = $('#low_stock').DataTable({
            "columnDefs": [
                {
                    "targets": [0,2],
                    "render": function (data, type, row) {
                        var date = new Date(data);
                        var options = {year: 'numeric', month: 'short', day: 'numeric' };
                        return date.toLocaleDateString('en-US', options);
                    },
                   
                },
                {
                    "className": "dt-center", "targets": "_all"
                }
            ],
            "processing" : true,
            "serverSide" : true, //serverside
            "order" : [], //enables table ordering
            "ajax" : {
                url:"../action/reports_action.php",
                type:"POST",
                data:{action:'lowstock', start_date:start_date, end_date:end_date}
            },
            // "drawCallback" : function(settings)
            // {
            //     var dateAdded = [];
            //     var expirationDate = [];
            //     var instock = [];
            //     var reductions = [];
            //     var startingQuantity = [];
            //     var medicineName = [];

            //     for(var count = 0; count < settings.aoData.length; count++)
            //     {
            //         //$order_column = array('dateAdded','medicineName','expirationDate','startingQuantity','instock','reductions');
            //         var dA = new Date(settings.aoData[count]._aData[0]);
            //         var eD = new Date(settings.aoData[count]._aData[2]);
            //         var options = {year: 'numeric', month: 'short', day: 'numeric' };
            //         dateAdded.push(dA.toLocaleDateString('en-US', options));
            //         expirationDate.push(eD.toLocaleDateString('en-US', options));
            //         // eggSize.push(settings.aoData[count]._aData[1]);
            //         medicineName.push(settings.aoData[count]._aData[1]);
            //         startingQuantity.push(parseFloat(settings.aoData[count]._aData[3]));
            //         instock.push(parseFloat(settings.aoData[count]._aData[4]));
            //         reductions.push(parseFloat(settings.aoData[count]._aData[5]));
            //     }
            //     console.log(dateAdded)
            //     // var chart_data = {
            //     //     labels:dateAdded,
            //     //     datasets:[
            //     //         {
            //     //             label : 'Total Quantity',
            //     //             backgroundColor : 'rgb(65,105,225)',
            //     //             color : '#fff',
            //     //             data:startingQuantity
            //     //         },
            //     //         {
            //     //             label : 'Total In Stock',
            //     //             backgroundColor : 'rgb(34, 139, 134)',
            //     //             color : '#fff',
            //     //             data:instock
            //     //         },
            //     //         {
            //     //             label : 'Quantity Reduced',
            //     //             backgroundColor : 'rgb(205,92,92)',
            //     //             color : '#fff',
            //     //             data:reductions
            //     //         }
            //     //     ]   
            //     // };

            //     // var group_chart3 = $('#bar_chart');

            //     // if(production_chart)
            //     // {
            //     //     production_chart.destroy();
            //     // }

            //     // production_chart = new Chart(group_chart3, {
            //     //     type:'bar',
            //     //     data:chart_data,
            //     // });
            // }
        });

        var dataTable = $('#feed_table').DataTable({
            "columnDefs": [
                {
                    "targets": [0],
                    "render": function (data, type, row) {
                        var date = new Date(data);
                        var options = {year: 'numeric', month: 'short', day: 'numeric' };
                        return date.toLocaleDateString('en-US', options);
                    },
                   
                },
                {
                    "className": "dt-center", "targets": "_all"
                }
            ],
            "processing" : true,
            "serverSide" : true, //serverside
            "order" : [], //enables table ordering
            "ajax" : {
                url:"../action/reports_action.php",
                type:"POST",
                data:{action:'feeds', start_date:start_date, end_date:end_date}
            },
            "drawCallback" : function(settings)
            {
                var datePurchased = [];
                var brand = [];
                var instock = [];
                var reductions = [];
                var startingQuantity = [];
                var feedName = [];

                for(var count = 0; count < settings.aoData.length; count++)
                {
                    //$order_column = array('datePurchased','feedName','brand','startingQuantity','inStock','reductions');
                    var dA = new Date(settings.aoData[count]._aData[0]);
                    var options = {year: 'numeric', month: 'short', day: 'numeric' };
                    datePurchased.push(dA.toLocaleDateString('en-US', options));
                    // eggSize.push(settings.aoData[count]._aData[1]);
                    feedName.push(settings.aoData[count]._aData[1]);
                    brand.push(settings.aoData[count]._aData[2]);
                    startingQuantity.push(parseFloat(settings.aoData[count]._aData[3]));
                    instock.push(parseFloat(settings.aoData[count]._aData[4]));
                    reductions.push(parseFloat(settings.aoData[count]._aData[5]));
                }
                console.log(datePurchased)
                var chart_data = {
                    labels:datePurchased,
                    datasets:[
                        {
                            label : 'Total Quantity',
                            backgroundColor : 'rgb(65,105,225)',
                            color : '#fff',
                            data:startingQuantity
                        },
                        {
                            label : 'Total In Stock',
                            backgroundColor : 'rgb(34, 139, 134)',
                            color : '#fff',
                            data:instock
                        },
                        {
                            label : 'Quantity Reduced',
                            backgroundColor : 'rgb(205,92,92)',
                            color : '#fff',
                            data:reductions
                        }
                    ]   
                };

                var group_chart3 = $('#feed_chart');

                if(feed_chart)
                {
                    feed_chart.destroy();
                }

                feed_chart = new Chart(group_chart3, {
                    type:'bar',
                    data:chart_data,
                });
            }
        });
    }
    
    $('#daterange_textbox').daterangepicker({
        
        ranges:{
            'Today' : [moment(), moment()],
            'Yesterday' : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
            'Last 30 Days' : [moment().subtract(29, 'days'), moment()],
            'This Month' : [moment().startOf('month'), moment().endOf('month')],
            'Last Month' : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
            'Last 12 Months': [moment().subtract(11, 'months').startOf('month'), moment().endOf('month')],
            'This Year': [moment().startOf('year'), moment().endOf('year')],
            'Last Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')]
        },
        format : 'YYYY-MM-DD',
        }, function(start, end){

            $('#medicine_table').DataTable().destroy();
            $('#list_medicines').DataTable().destroy();
            $('#low_stock').DataTable().destroy();
            $('#feed_table').DataTable().destroy();
            fetch_data(start.format('YYYY-MM-DD'), end.format('YYYY-MM-DD'));

        });


    });

</script>