<?php
    //title of the pge
    $title = "Medicine Inventory - Reductions";

    //header
    include("../../includes/header.php");
?>
<!-- content --> 
<div class="container-fluid px-4">
    <h1 class="mt-4"> Manager Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">
            <a href="./index.php" style="text-decoration: none">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Feed Inventory</li>
    </ol>

    <div class="wrapper">
        <div class="container">
            <div class="row mb-5">
                <div class="p-0">
                    <div class="card  shadow-lg">
                        <div class="card-header" style="background-color: #f37e57;">

                            <!-- <div class="w-100 d-flex justify-content-between p-2">
                                <div>
                                    <h4 class="pt-2 fs-5 fw-bold">Feed Reductions</h4>
                                </div>

                                <div>
                                    <a href=".php" class="btn btn-danger pt-2">Add Reduction</a>
                                </div>
                            </div> -->
                            <div class="row justify-content-between">
                                <div class="col-xl-3 col-md-6">
                                    <h4 class="pt-2 fs-5 fw-bold">Feed Reduction</h4>
                                </div>

                                <div class="col-xl-4 col-md-6 align-content-end">
                                    <div class="w-100 d-flex justify-content-end">
                                        <div class="m-1 w-100 float-end">
                                            <a href="reduction_feeds_form.php" class="btn btn-success shadow-sm w-100 fw-bold">Add Reduction</a>
                                        </div>
                                        <div class="m-1 w-100">
                                            <a href="#" class="btn btn-danger shadow-sm w-100 fw-bold">Archives</a>                                 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="table-responsive m-1">
                                <?php
                                    // Include config file
                                    include('./query/feed_reduction_records.php');
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>        
        </div>
    </div>
    

</div>
<!-- end of content -->
<?php
    include("../../includes/footer.php");

    include("../../includes/scripts.php");
?>