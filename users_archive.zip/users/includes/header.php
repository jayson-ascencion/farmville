<?php
//start the session
session_start();
ob_start();

if($_SESSION["loggedin"]===true){ 
    if($_SESSION['role']===1){
        include('auth.php');
    }else if($_SESSION['role']===2){
        include('auth.php');
    }else if($_SESSION['role']===3){
        include('auth.php');
    }
}else{
    header("Location: ../../../login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo $title; ?></title>

        <!-- farmville icon --> 
        <link rel="icon" type="image/x-icon" href="../../../assets/images/favicon.ico">

        <!-- css files  --> 
        <link rel="stylesheet" type="text/css" href="../../../assets/css/styles.css" />
        <link rel="stylesheet" type="text/css" href="../../../assets/css/datatables.min.css">

        <!-- Pagination Source - https://www.youtube.com/watch?v=nMzz1ZIET1A - https://datatables.net/manual/installation -->
        <!-- js files #f4f6fa 
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script> -->

        <!--css for chart-->
        <style>
        * {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
        }
        .chartMenu {
            width: 100vw;
            height: 40px;
            background: #1A1A1A;
            color: rgba(255, 26, 104, 1);
        }
        .chartMenu p {
            padding: 10px;
            font-size: 20px;
        }
        .chartCard {
            width: 100vw;
            height: calc(100vh - 40px);
            background: rgba(255, 26, 104, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .chartBox {
            width: 700px;
            padding: 20px;
            border-radius: 20px;
            border: solid 3px rgba(255, 26, 104, 1);
            background: white;
        }
    </style>
    </head>

    <body class="sb-nav-fixed" style="background-color: #ffe7d6">

        <!-- navbar-top -->
        <?php 
        include('navbar-top.php');
        ?>

        <div id="layoutSidenav">
    
        <!-- sidebar -->
        <?php
        include('sidebar.php');
        ?>
    
        <div id="layoutSidenav_content">
        <main>



