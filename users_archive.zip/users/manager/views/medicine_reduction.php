<?php
    //title of the pge
    $title = "Medicine Inventory - Reductions";

    include("../../includes/header.php");

?>
<!-- content --> 
<div class="container-fluid px-4">
    <h1 class="mt-4"> Manager Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">
            <a href="./index.php" style="text-decoration: none">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Medicine Inventory</li>
    </ol>

    <div class="wrapper">
        <div class="container">
            <div class="row mb-5">
                <div class="p-0">
                    <div class="card shadow-sm">
                        <div class="card-header justify-content-between" style="background-color: #f37e57;">

                            <div class="row justify-content-between">
                                <div class="col-xl-3 col-md-6">
                                    <h4 class="pt-2 fs-5 fw-bold">Medicine Reductions</h4>
                                </div>

                                <div class="col-xl-4 col-md-6 align-content-end">
                                    <div class="w-100 d-flex justify-content-end">
                                        <div class="m-1 w-100 float-end">
                                            <a href="reduction_medicine_form.php" class="btn btn-success shadow-sm w-100 fw-bold">Add Reduction</a>
                                        </div>
                                        <div class="m-1 w-100">
                                            <a href="med_reduction_archives.php" class="btn btn-danger shadow-sm w-100 fw-bold">Archives</a>                                 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                        <div class="card-body">
                            <div class="table-responsive m-1">
                                <?php
                                    // Include config file
                                    include('./query/medicine_reduction_records.php');
                                ?>
                            </div>
                        </div>
                    </div>

                    <!-- Modal -->
                    <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
            <input type="text" class="form-control" name="idkl" id="idkl" value="">
            <div class="w-100 d-flex justify-content-end">
                                        <div class="w-100 m-1">
                                            <a class="small btn btn-sm btn-outline-danger fw-bold w-100" data-bs-dismiss="modal">
                                                No
                                            </a> 
                                        </div>
                                        <div class="w-100 m-1">
                                            <button type="submit" name="archiveRecord" class="btn btn-sm btn-outline-success fw-bold w-100">
                                                Yes
                                            </button>                                    
                                        </div>
                                    </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
                    <!-- <div class="modal fade" id="archiveModal" tabindex="-1" aria-labelledby="archiveModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-body"><?php $id = $_REQUEST['id']; ?>
                                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
                                    <input type="text" name="archive_id" value="">
                                    <h6 class="fw-bold p-1"> Do you want to archive this record?</h6>
                                    <div class="w-100 d-flex justify-content-end">
                                        <div class="w-100 m-1">
                                            <a class="small btn btn-sm btn-outline-danger fw-bold w-100" data-bs-dismiss="modal">
                                                No
                                            </a> 
                                        </div>
                                        <div class="w-100 m-1">
                                            <button type="submit" name="archiveRecord" class="btn btn-sm btn-outline-success fw-bold w-100">
                                                Yes
                                            </button>                                    
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div> -->

                </div>
            </div>        
        </div>
    </div>
    

</div>
<!-- end of content -->
<?php
    include("../../includes/footer.php");

    include("../../includes/scripts.php");

?>