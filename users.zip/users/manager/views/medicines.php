<?php
    //title of the pge
    $title = "Medicine Inventory";

    include("../../includes/header.php");

?>
<!-- content --> 
<div class="container-fluid px-4">
    <h1 class="mt-4"> Manager Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">
            <a href="./index.php" style="text-decoration: none">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Medicine Inventory</li>
    </ol>

    <div class="wrapper">
        <div class="container">
            <div class="row mb-5">
                <div class="p-0">
                    <div class="card shadow-lg ">
                        <div class="card-header">

                            <div class="w-100 d-flex justify-content-between p-2">
                                <div>
                                    <h4 class="pt-2 fs-5 fw-bold">Medicines</h4>
                                </div>

                                <div>
                                    <a href="add_medicine_form.php" class="btn btn-primary pt-2">Add New Medicine</a>
                                    
                                </div>
                            </div>
                        
                        </div>

                        <div class="card-body">
                            <div class="table-responsive m-1">
                                <?php
                                    // Include config file
                                    include('./query/medicine_records.php');
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>        
        </div>
    </div>
    

</div>
<!-- end of content -->
<?php
    include("../../includes/footer.php");

    include("../../includes/scripts.php");

?>