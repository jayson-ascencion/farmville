<?php
    //title of the pge
    $title = "Chicken Production";

    //header
    include("../../includes/header.php");
    
?>


        <div class="container-fluid px-4">
            
            <h1 class="mt-4"> Manager Dashboard</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item">
                    <a href="./index.php" style="text-decoration: none">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Feeds Inventory</li>
            </ol>
            <div class="wrapper mb-5">
                <div class="container">
                    <div class="row">
                        <div class="p-0">
                            <div class="card shadow-lg">
                                <div class="card-header rounded rounded-3"  style="background-color: #f37e57;">
                                    <!-- <div class="row">
                                        <div class="col col-sm-9">Sales Data</div>
                                        <div class="col col-sm-3">
                                            <input type="text" id="daterange_textbox" class="form-control" readonly />
                                        </div>
                                    </div> -->

                                    <div class="row justify-content-between">
                                        <div class="col-xl-6 col-md-6">
                                            <h4 class="pt-2 fs-5 fw-bold">Reports</h4>
                                        </div>

                                        <div class="col-xl-3 col-md-3 align-content-end">
                                            <div class="w-100 d-flex text-center  justify-content-end">
                                                <!-- <div class="m-1 w-100 float-end">
                                                    <a href="add_feeds_form.php" class="btn btn-success shadow-sm w-100 fw-bold">Add Feeds</a>style="width: 250px"
                                                </div> -->
                                                <input type="text" id="daterange_textbox" class="form-control bg-success text-center"  readonly/>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="card mt-3 shadow-lg">
 <div class="card-body">
                                    <div class="table-responsive m-1">
                                        <h5 class="text-center" style="color: rgb(100, 100, 100)">Egg Report</h5>
                                        <div class="chart-container bar-chart">
                                            <canvas id="bar_chart" height="100"> </canvas>
                                        </div>
                                        <table class="table responsive border table-hover text-center rounde rounded-3 overflow-hidden" style="width: 100%" id="production_table">
                                            <thead class="bg-dark text-white">
                                                <tr>
                                                    <th>Collection Date</th>
                                                    <th>Quantity Collected</th>
                                                    <th>Reductions</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                                <!-- <hr class="border border-dark border-3 opacity-75"> -->
                            <div class="card mt-3 shadow-lg">
<div class="card-body">
                                    <div class="table-responsive m-1">
                                        <h5 class="text-center" style="color: rgb(100, 100, 100)">Summary By Reduction Type</h5>
                                        <div class="chart-container bar-chart">
                                            <canvas id="second_chart" height="100"> </canvas>
                                        </div>
                                        <table class="table responsive border table-hover text-center rounde rounded-3 overflow-hidden" style="width: 100%" id="second_table">
                                            <thead class="bg-dark text-white">
                                                <tr>
                                                    <th>Reduction Type</th>
                                                    <th>Reductions</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>


                                <!-- <hr class="border border-dark border-3 opacity-75"> -->
                            <div class="card mt-3 shadow-lg">
 <div class="card-body">
                                    <div class="table-responsive m-1">
                                        <h5 class="text-center" style="color: rgb(100, 100, 100)">In Stock Summary By Egg Size</h5>
                                        <div class="chart-container container bar-chart">
                                            <canvas id="third_chart" height="100"> </canvas>
                                        </div>
                                        <table class="table responsive border table-hover text-center rounde rounded-3 overflow-hidden" style="width: 100%" id="third_table">
                                            <thead class="bg-dark text-white">
                                                <tr>
                                                    <th>Egg Size</th>
                                                    <th>In Stock</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                           


                                

                               
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>

<script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous" async defer></script>
<script src="../../../assets/js/jquery-3.6.1.min.js"></script>
<script src="../../../assets/js/bootstrap5.bundle.min.js" crossorigin="anonymous"></script>
<script src="../../../assets/js/scripts.js"></script>
<script src="../../../assets/js/moment.js"></script>
<script src="../../../assets/js/popper.min.js"></script>
<script src="../../../assets/js/datatables.min.js"></script>
<script src="../../../assets/js/daterangepicker.js"></script>
<script src="../../../assets/js/pdfmake.min.js"></script>
<script src="../../../assets/js/vfs_fonts.js"></script>
<script src="../../../assets/js/chart.js"></script>
<script src="../../../assets/js/chartjs-adapter-date-fns.bundle.min.js"></script>
<script>
    $.extend( $.fn.dataTable.defaults, {
        // "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
        // "lengthMenu": [[-1, 10, 25, 50, 100], ["All", 10, 25, 50, 100]],
        "pageLength": -1,
        responsive: true,
        stateSave: true,
        columnDefs: [
            {"className": "dt-center", "targets": "_all"} //center all text in the table
        ],
    });
    $(document).ready(function(){

    // fetch_data();

    var production_chart;
    var second_chart;
    var third_chart;

    // var start = moment().format('YYYY-MM-DD');
    // var end = moment().format('YYYY-MM-DD');
    // // fetch_data();
    // fetch_data(moment().format('YYYY-MM-DD'), moment().format('YYYY-MM-DD'));

    // $('#daterange_textbox').data('daterangepicker').setStartDate(moment().format('YYYY-MM-DD'));
    // $('#daterange_textbox').data('daterangepicker').setEndDate(moment().format('YYYY-MM-DD'));
    // fetch_data();
    fetch_data(moment().format('YYYY-MM-DD'), moment().format('YYYY-MM-DD'));

    //function to fetch data
    function fetch_data(start_date = '', end_date = '')
    {
        //creates the table
        //production table
        var dataTable = $('#production_table').DataTable({
            "columnDefs": [
                {
                    "targets": 0,
                    "render": function (data, type, row) {
                        var date = new Date(data);
                        var options = {year: 'numeric', month: 'short', day: 'numeric' };
                        return date.toLocaleDateString('en-US', options);
                    },
                   
                },
                {
                    "className": "dt-center", "targets": "_all"
                }
            ],
            "processing" : true,
            "serverSide" : true, //serverside
            "order" : [], //enables table ordering
            "ajax" : {
                url:"../action/reports_action.php",
                type:"POST",
                data:{action:'egg', start_date:start_date, end_date:end_date}
            },
            "drawCallback" : function(settings)
            {
                var collectionDate = [];
                var totalQuantity = [];
                var reductions = [];

                for(var count = 0; count < settings.aoData.length; count++)
                {
                    var date = new Date(settings.aoData[count]._aData[0]);
                    var options = {year: 'numeric', month: 'short', day: 'numeric' };
                    collectionDate.push(date.toLocaleDateString('en-US', options));
                    // eggSize.push(settings.aoData[count]._aData[1]);
                    totalQuantity.push(parseFloat(settings.aoData[count]._aData[1]));
                    reductions.push(parseFloat(settings.aoData[count]._aData[2]));
                }
                console.log(collectionDate)
                var chart_data = {
                    labels:collectionDate,
                    datasets:[
                        {
                            label : 'Total Quantity',
                            backgroundColor : 'rgb(65,105,225)',
                            color : '#fff',
                            data:totalQuantity
                        },
                        {
                            label : 'Quantity Reduced',
                            backgroundColor : 'rgb(205,92,92)',
                            color : '#fff',
                            data:reductions
                        }
                    ]   
                };

                var group_chart3 = $('#bar_chart');

                if(production_chart)
                {
                    production_chart.destroy();
                }

                production_chart = new Chart(group_chart3, {
                    type:'bar',
                    data:chart_data,
                });
            }
        });

        //second table
        var dataTable = $('#second_table').DataTable({
            info: false,
            paging: false,
            filter: false,
            stateSave: true,
            "processing" : true,
            "serverSide" : true, //serverside
            "order" : [], //enables table ordering
            "ajax" : {
                url:"../action/reports_action.php",
                type:"POST",
                data:{action:'egg_reduction', start_date:start_date, end_date:end_date}
            },
            "drawCallback" : function(settings)
            {
                
                var reductionType = [];
                var reductions = [];
                
                for(var count = 0; count < settings.aoData.length; count++)
                {
                    reductionType.push(settings.aoData[count]._aData[0]);
                    reductions.push(parseFloat(settings.aoData[count]._aData[1]));
                }

                var chart_data = {
                    labels: reductionType,
                    datasets: [
                        {
                            label: 'Quantity Reduced',
                            backgroundColor: 'rgba(205,92,92)',
                            color: '#fff',
                            data: reductions
                        }
                    ],

                };
                
                var group_chart3 = $('#second_chart');

                if(second_chart)
                {
                    second_chart.destroy();
                }

                second_chart = new Chart(group_chart3, {
                    type:'bar',
                    data:chart_data
                });
            }
        });

        //third table
        var dataTable = $('#third_table').DataTable({
            info: false,
            paging: false,
            filter: false,
            stateSave: true,
            "processing" : true,
            "serverSide" : true, //serverside
            "order" : [], //enables table ordering
            "ajax" : {
                url:"../action/reports_action.php",
                type:"POST",
                data:{action:'eggsize', start_date:start_date, end_date:end_date}
            },
            "drawCallback" : function(settings)
            {
                
                var breedType = [];
                var instock = [];
                
                for(var count = 0; count < settings.aoData.length; count++)
                {
                    breedType.push(settings.aoData[count]._aData[0]);
                    instock.push(parseFloat(settings.aoData[count]._aData[1]));
                }

                var chart_data = {
                    labels: breedType,
                    datasets: [
                        {
                            label: 'Quantity In Stock',
                            backgroundColor: [
                                'rgba(153, 102, 255)',
                                'rgba(255, 99, 132)', 
                                'rgba(255, 159, 64)', 
                                'rgba(255, 205, 86)', 
                                'rgba(75, 192, 192)'
                            ],
                            color: '#fff',
                            data: instock
                        }
                    ],

                };
                
                var group_chart3 = $('#third_chart');

                if(third_chart)
                {
                    third_chart.destroy();
                }

                third_chart = new Chart(group_chart3, {
                    type:'bar',
                    data:chart_data
                });
            }
        });
    }
    
    $('#daterange_textbox').daterangepicker({
        
        ranges:{
            'Today' : [moment(), moment()],
            'Yesterday' : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
            'Last 30 Days' : [moment().subtract(29, 'days'), moment()],
            'This Month' : [moment().startOf('month'), moment().endOf('month')],
            'Last Month' : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
            'Last 12 Months': [moment().subtract(11, 'months').startOf('month'), moment().endOf('month')],
            'This Year': [moment().startOf('year'), moment().endOf('year')],
            'Last Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')]
        },
        format : 'YYYY-MM-DD',
    }, function(start, end){

        $('#production_table').DataTable().destroy();
        $('#second_table').DataTable().destroy();
        $('#third_table').DataTable().destroy();
        fetch_data(start.format('YYYY-MM-DD'), end.format('YYYY-MM-DD'));

    });


    });

</script>