<?php

//database connection, located in the config directory
include('../../../config/database_connection.php');

if(isset($_POST["action"]))
{
	//-------------------------CHICKEN REPORT-----------------------------//
	if($_POST["action"] == 'fetch')
	{
		// $order_column = array('chickenBatch_ID', 'instock', 'dateAcquired', 'totalQuantity');

		$order_column = array('dateAcquired','totalQuantity', 'instock','reductions');

		// $main_query = "
		// SELECT chickenBatch_ID, SUM(COALESCE(inStock,0)) AS inStock, dateAcquired, SUM(COALESCE(startingQuantity,0)) as totalQuantity
		// FROM chickenproduction
		// ";

		$main_query = "
		SELECT cp.chickenBatch_ID, SUM(COALESCE(cp.inStock,0)) AS inStock, cp.dateAcquired, SUM(COALESCE(cp.startingQuantity,0)) as totalQuantity, SUM(COALESCE(cr.quantity,0)) as reductions
		FROM chickenproduction cp
		LEFT JOIN chickenreduction cr ON cp.chickenBatch_ID = cr.chickenBatch_ID
		";

		$search_query = ' WHERE cp.archive = "not archived" AND ';

		if(isset($_POST["start_date"], $_POST["end_date"]) && $_POST["start_date"] != '' && $_POST["end_date"] != '')
		{
			$search_query .= 'cp.dateAcquired >= "'.$_POST["start_date"].'" AND cp.dateAcquired <= "'.$_POST["end_date"].'" AND ';
		}

		if(isset($_POST["search"]["value"]))
		{
			$search_query .= '(cp.chickenBatch_ID LIKE "%'.$_POST["search"]["value"].'%" OR inStock LIKE "%'.$_POST["search"]["value"].'%" OR cp.dateAcquired LIKE "%'.$_POST["search"]["value"].'%")';
		}

		$group_by_query = " GROUP BY cp.dateAcquired ";

		$order_by_query = "";

		if(isset($_POST["order"]))
		{
			$order_by_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$order_by_query = 'ORDER BY cp.dateAcquired DESC ';
		}

		$limit_query = '';

		if($_POST["length"] != -1)
		{
			$limit_query = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}

		$statement = $conn->prepare($main_query . $search_query . $group_by_query . $order_by_query);

		$statement->execute();

		$filtered_rows = $statement->rowCount();

		$statement = $conn->prepare($main_query . $group_by_query);

		$statement->execute();

		$total_rows = $statement->rowCount();

		$result = $conn->query($main_query . $search_query . $group_by_query . $order_by_query . $limit_query, PDO::FETCH_ASSOC);

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();

			$sub_array[] = $row['dateAcquired'];

			// $sub_array[] = $row['chickenBatch_ID'];

			$sub_array[] = $row['totalQuantity'];

			$sub_array[] = $row['inStock'];

			$sub_array[] = $row['reductions'];

			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"	=>	$total_rows,
			"recordsFiltered" => $filtered_rows,
			"data"			=>	$data
		);

		echo json_encode($output);
	}

	if($_POST["action"] == 'reduction')
	{
		$order_column = array('reductionType','reductions');

		$reductions_query = "
		SELECT reductionType, SUM(COALESCE(quantity, 0)) as reductions
		FROM chickenreduction
		";

		$search_query = ' WHERE ';

		if(isset($_POST["start_date"], $_POST["end_date"]) && $_POST["start_date"] != '' && $_POST["end_date"] != '')
		{
			$search_query .= ' dateReduced >= "'.$_POST["start_date"].'" AND dateReduced <= "'.$_POST["end_date"].'" AND ';
		}

		if(isset($_POST["search"]["value"]))
		{
			$search_query .= ' (dateReduced LIKE "%'.$_POST["search"]["value"].'%")';
		}

		$group_by_query = " GROUP BY reductionType ";

		
		$order_by_query = "";

		if(isset($_POST["order"]))
		{
			$order_by_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$order_by_query = 'ORDER BY reductions DESC ';
		}

		$statement = $conn->prepare($reductions_query . $search_query . $group_by_query . $order_by_query);

		$statement->execute();

		$filtered_rows = $statement->rowCount();

		$statement = $conn->prepare($reductions_query . $group_by_query);

		$statement->execute();

		$total_rows = $statement->rowCount();

		$result = $conn->query($reductions_query . $search_query . $group_by_query . $order_by_query, PDO::FETCH_ASSOC);

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();

			$sub_array[] = $row['reductionType'];

			$sub_array[] = $row['reductions'];

			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"	=>	$total_rows,
			"recordsFiltered" => $filtered_rows,
			"data"			=>	$data
		);
		
		echo json_encode($output);
	}

	if($_POST["action"] == 'breed')
	{
		$order_column = array('breedType','instock');

		$reductions_query = "
		SELECT breedType, SUM(COALESCE(inStock, 0)) as instock
		FROM chickenproduction
		";

		$search_query = ' WHERE archive = "not archived" AND ';

		if(isset($_POST["start_date"], $_POST["end_date"]) && $_POST["start_date"] != '' && $_POST["end_date"] != '')
		{
			$search_query .= ' dateAcquired >= "'.$_POST["start_date"].'" AND dateAcquired <= "'.$_POST["end_date"].'" AND ';
		}

		if(isset($_POST["search"]["value"]))
		{
			$search_query .= ' (dateAcquired LIKE "%'.$_POST["search"]["value"].'%")';
		}

		$group_by_query = " GROUP BY breedType ";

		
		$order_by_query = "";

		if(isset($_POST["order"]))
		{
			$order_by_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$order_by_query = 'ORDER BY breedType DESC ';
		}

		$statement = $conn->prepare($reductions_query . $search_query . $group_by_query . $order_by_query);

		$statement->execute();

		$filtered_rows = $statement->rowCount();

		$statement = $conn->prepare($reductions_query . $group_by_query);

		$statement->execute();

		$total_rows = $statement->rowCount();

		$result = $conn->query($reductions_query . $search_query . $group_by_query . $order_by_query, PDO::FETCH_ASSOC);

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();

			$sub_array[] = $row['breedType'];

			$sub_array[] = $row['instock'];

			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"	=>	$total_rows,
			"recordsFiltered" => $filtered_rows,
			"data"			=>	$data
		);
		
		echo json_encode($output);
	}


	//---------------------------------EGG REPORT----------------------------------//
	if($_POST["action"] == 'egg')
	{
		$order_column = array('collectionDate', 'totalQuantity','totalReductions');

		$main_query = "
		SELECT ep.collectionDate, ep.eggSize, SUM(COALESCE(ep.quantity,0)) as totalQuantity, SUM(COALESCE(er.quantity,0)) as totalReductions 
		FROM eggproduction ep 
		LEFT JOIN eggreduction er ON ep.eggBatch_ID = er.eggBatch_ID 
		";

		$search_query = ' WHERE ep.archive = "not archived" AND ';

		if(isset($_POST["start_date"], $_POST["end_date"]) && $_POST["start_date"] != '' && $_POST["end_date"] != '')
		{
			$search_query .= 'ep.collectionDate >= "'.$_POST["start_date"].'" AND ep.collectionDate <= "'.$_POST["end_date"].'" AND ';
		}

		if(isset($_POST["search"]["value"]))
		{
			$search_query .= '(ep.eggBatch_ID LIKE "%'.$_POST["search"]["value"].'%" OR ep.eggSize LIKE "%'.$_POST["search"]["value"].'%" OR ep.collectionDate LIKE "%'.$_POST["search"]["value"].'%")';
		}

		$group_by_query = " GROUP BY ep.collectionDate ";

		$order_by_query = "";

		if(isset($_POST["order"]))
		{
			$order_by_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$order_by_query = 'ORDER BY ep.collectionDate DESC ';
		}

		$limit_query = '';

		if($_POST["length"] != -1)
		{
			$limit_query = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}

		$statement = $conn->prepare($main_query . $search_query . $group_by_query . $order_by_query);

		$statement->execute();

		$filtered_rows = $statement->rowCount();

		$statement = $conn->prepare($main_query . $group_by_query);

		$statement->execute();

		$total_rows = $statement->rowCount();

		$result = $conn->query($main_query . $search_query . $group_by_query . $order_by_query . $limit_query, PDO::FETCH_ASSOC);

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();

			$sub_array[] = $row['collectionDate'];

			// $sub_array[] = $row['eggSize'];

			$sub_array[] = $row['totalQuantity'];

			$sub_array[] = $row['totalReductions'];

			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"	=>	$total_rows,
			"recordsFiltered" => $filtered_rows,
			"data"			=>	$data
		);

		echo json_encode($output);
	}

	if($_POST["action"] == 'egg_reduction')
	{
		$order_column = array('reductionType','reductions');

		$reductions_query = "
		SELECT reductionType, SUM(COALESCE(quantity, 0)) as reductions
		FROM eggreduction
		";

		$search_query = ' WHERE ';

		if(isset($_POST["start_date"], $_POST["end_date"]) && $_POST["start_date"] != '' && $_POST["end_date"] != '')
		{
			$search_query .= ' dateReduced >= "'.$_POST["start_date"].'" AND dateReduced <= "'.$_POST["end_date"].'" AND ';
		}

		if(isset($_POST["search"]["value"]))
		{
			$search_query .= ' (dateReduced LIKE "%'.$_POST["search"]["value"].'%")';
		}

		$group_by_query = " GROUP BY reductionType ";

		
		$order_by_query = "";

		if(isset($_POST["order"]))
		{
			$order_by_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$order_by_query = 'ORDER BY reductions DESC ';
		}

		$statement = $conn->prepare($reductions_query . $search_query . $group_by_query . $order_by_query);

		$statement->execute();

		$filtered_rows = $statement->rowCount();

		$statement = $conn->prepare($reductions_query . $group_by_query);

		$statement->execute();

		$total_rows = $statement->rowCount();

		$result = $conn->query($reductions_query . $search_query . $group_by_query . $order_by_query, PDO::FETCH_ASSOC);

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();

			$sub_array[] = $row['reductionType'];

			$sub_array[] = $row['reductions'];

			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"	=>	$total_rows,
			"recordsFiltered" => $filtered_rows,
			"data"			=>	$data
		);
		
		echo json_encode($output);
	}

	if($_POST["action"] == 'eggsize')
	{
		$order_column = array('eggSize','instock');

		$reductions_query = "
		SELECT eggSize, SUM(COALESCE(quantity, 0)) as instock FROM eggproduction
		";

		$search_query = ' WHERE archive = "not archived" AND ';

		if(isset($_POST["start_date"], $_POST["end_date"]) && $_POST["start_date"] != '' && $_POST["end_date"] != '')
		{
			$search_query .= ' collectionDate >= "'.$_POST["start_date"].'" AND collectionDate <= "'.$_POST["end_date"].'" AND ';
		}

		if(isset($_POST["search"]["value"]))
		{
			$search_query .= ' (collectionDate LIKE "%'.$_POST["search"]["value"].'%")';
		}

		$group_by_query = " GROUP BY eggSize ";

		
		$order_by_query = "";

		if(isset($_POST["order"]))
		{
			$order_by_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$order_by_query = 'ORDER BY eggSize DESC ';
		}

		$statement = $conn->prepare($reductions_query . $search_query . $group_by_query . $order_by_query);

		$statement->execute();

		$filtered_rows = $statement->rowCount();

		$statement = $conn->prepare($reductions_query . $group_by_query);

		$statement->execute();

		$total_rows = $statement->rowCount();

		$result = $conn->query($reductions_query . $search_query . $group_by_query . $order_by_query, PDO::FETCH_ASSOC);

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();

			$sub_array[] = $row['eggSize'];

			$sub_array[] = $row['instock'];

			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"	=>	$total_rows,
			"recordsFiltered" => $filtered_rows,
			"data"			=>	$data
		);
		
		echo json_encode($output);
	}

	//----------------------MEDICINE REPORTS--------------------//
	if($_POST["action"] == 'medicine')
	{
		$order_column = array('dateAdded','medicineName','expirationDate','startingQuantity','inStock','reductions');

		$main_query = "
		SELECT m.dateAdded, m.medicineName, m.expirationDate, m.startingQuantity, m.inStock, SUM(COALESCE(mr.quantity,0)) AS reductions
		FROM medicines m
		LEFT JOIN medicinereduction mr ON m.medicine_ID = mr.medicine_ID
		";

		$search_query = ' WHERE m.archive = "not archived" AND ';

		if(isset($_POST["start_date"], $_POST["end_date"]) && $_POST["start_date"] != '' && $_POST["end_date"] != '')
		{
			$search_query .= 'm.dateAdded >= "'.$_POST["start_date"].'" AND m.dateAdded <= "'.$_POST["end_date"].'" AND ';
		}

		if(isset($_POST["search"]["value"]))
		{
			$search_query .= '(m.dateAdded LIKE "%'.$_POST["search"]["value"].'%")';
		}

		$group_by_query = " GROUP BY m.medicine_ID "; // AND m.dateAdded

		$order_by_query = "";

		if(isset($_POST["order"]))
		{
			$order_by_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$order_by_query = 'ORDER BY m.dateAdded DESC ';
		}

		$limit_query = '';

		if($_POST["length"] != -1)
		{
			$limit_query = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}

		$statement = $conn->prepare($main_query . $search_query . $group_by_query . $order_by_query);

		$statement->execute();

		$filtered_rows = $statement->rowCount();

		$statement = $conn->prepare($main_query . $group_by_query);

		$statement->execute();

		$total_rows = $statement->rowCount();

		$result = $conn->query($main_query . $search_query . $group_by_query . $order_by_query . $limit_query, PDO::FETCH_ASSOC);

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();

			$sub_array[] = $row['dateAdded'];

			$sub_array[] = $row['medicineName'];

			$sub_array[] = $row['expirationDate'];

			$sub_array[] = $row['startingQuantity'];

			$sub_array[] = $row['inStock'];

			$sub_array[] = $row['reductions'];

			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"	=>	$total_rows,
			"recordsFiltered" => $filtered_rows,
			"data"			=>	$data
		);

		echo json_encode($output);
	}

	if($_POST["action"] == 'toexpire')
	{
		$order_column = array('dateAdded','medicineName','expirationDate','startingQuantity','inStock');

		$main_query = "
		SELECT dateAdded, medicineName, expirationDate, startingQuantity, inStock
		FROM medicines
		";

		$search_query = ' WHERE archive = "not archived" AND DATEDIFF(expirationDate, NOW()) <=60 ';

		// if(isset($_POST["start_date"], $_POST["end_date"]) && $_POST["start_date"] != '' && $_POST["end_date"] != '')
		// {
		// 	$search_query .= 'm.dateAdded >= "'.$_POST["start_date"].'" AND m.dateAdded <= "'.$_POST["end_date"].'" AND ';
		// }

		// if(isset($_POST["search"]["value"]))
		// {
		// 	$search_query .= '(m.dateAdded LIKE "%'.$_POST["search"]["value"].'%")';
		// }

		// $group_by_query = " GROUP BY m.medicine_ID "; // AND m.dateAdded

		// $order_by_query = "";

		// if(isset($_POST["order"]))
		// {
		// 	$order_by_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		// }
		// else
		// {
		// 	$order_by_query = 'ORDER BY m.dateAdded DESC ';
		// }

		// $limit_query = '';

		// if($_POST["length"] != -1)
		// {
		// 	$limit_query = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		// }

		$statement = $conn->prepare($main_query . $search_query ); //. $group_by_query . $order_by_query

		$statement->execute();

		$filtered_rows = $statement->rowCount();

		// $statement = $conn->prepare($main_query . $group_by_query);

		// $statement->execute();

		$total_rows = $statement->rowCount();

		$result = $conn->query($main_query . $search_query , PDO::FETCH_ASSOC); //. $group_by_query . $order_by_query . $limit_query

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();

			$sub_array[] = $row['dateAdded'];

			$sub_array[] = $row['medicineName'];

			$sub_array[] = $row['expirationDate'];

			$sub_array[] = $row['startingQuantity'];

			$sub_array[] = $row['inStock'];

			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"	=>	$total_rows,
			"recordsFiltered" => $filtered_rows,
			"data"			=>	$data
		);

		echo json_encode($output);
	}

	if($_POST["action"] == 'lowstock')
	{
		$order_column = array('dateAdded','medicineName','expirationDate','startingQuantity','inStock');

		$main_query = "
		SELECT dateAdded, medicineName, expirationDate, startingQuantity, inStock
		FROM medicines
		";

		$search_query = ' WHERE archive = "not archived" AND inStock <=10 ';

		// if(isset($_POST["start_date"], $_POST["end_date"]) && $_POST["start_date"] != '' && $_POST["end_date"] != '')
		// {
		// 	$search_query .= 'm.dateAdded >= "'.$_POST["start_date"].'" AND m.dateAdded <= "'.$_POST["end_date"].'" AND ';
		// }

		// if(isset($_POST["search"]["value"]))
		// {
		// 	$search_query .= '(m.dateAdded LIKE "%'.$_POST["search"]["value"].'%")';
		// }

		// $group_by_query = " GROUP BY m.medicine_ID "; // AND m.dateAdded

		// $order_by_query = "";

		// if(isset($_POST["order"]))
		// {
		// 	$order_by_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		// }
		// else
		// {
		// 	$order_by_query = 'ORDER BY m.dateAdded DESC ';
		// }

		// $limit_query = '';

		// if($_POST["length"] != -1)
		// {
		// 	$limit_query = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		// }

		$statement = $conn->prepare($main_query . $search_query ); //. $group_by_query . $order_by_query

		$statement->execute();

		$filtered_rows = $statement->rowCount();

		// $statement = $conn->prepare($main_query . $group_by_query);

		// $statement->execute();

		$total_rows = $statement->rowCount();

		$result = $conn->query($main_query . $search_query , PDO::FETCH_ASSOC); //. $group_by_query . $order_by_query . $limit_query

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();

			$sub_array[] = $row['dateAdded'];

			$sub_array[] = $row['medicineName'];

			$sub_array[] = $row['expirationDate'];

			$sub_array[] = $row['startingQuantity'];

			$sub_array[] = $row['inStock'];

			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"	=>	$total_rows,
			"recordsFiltered" => $filtered_rows,
			"data"			=>	$data
		);

		echo json_encode($output);
	}

	//----------------------FEEDS REPORTS--------------------//
	if($_POST["action"] == 'feeds')
	{
		$order_column = array('datePurchased','feedName','brand','startingQuantity','inStock','reductions');

		$main_query = "
		SELECT f.datePurchased, f.feedName, f.brand, f.startingQuantity, f.inStock, SUM(COALESCE(fr.quantity,0)) AS reductions
		FROM feeds f
		LEFT JOIN feedreduction fr ON f.feed_ID = fr.feed_ID
		";

		$search_query = ' WHERE f.archive = "not archived" AND ';

		if(isset($_POST["start_date"], $_POST["end_date"]) && $_POST["start_date"] != '' && $_POST["end_date"] != '')
		{
			$search_query .= 'f.datePurchased >= "'.$_POST["start_date"].'" AND f.datePurchased <= "'.$_POST["end_date"].'" AND ';
		}

		if(isset($_POST["search"]["value"]))
		{
			$search_query .= '(f.datePurchased LIKE "%'.$_POST["search"]["value"].'%")';
		}

		$group_by_query = " GROUP BY f.feed_ID "; // AND f.datePurchased

		$order_by_query = "";

		if(isset($_POST["order"]))
		{
			$order_by_query = 'ORDER BY '.$order_column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
		}
		else
		{
			$order_by_query = 'ORDER BY f.datePurchased DESC ';
		}

		$limit_query = '';

		if($_POST["length"] != -1)
		{
			$limit_query = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}

		$statement = $conn->prepare($main_query . $search_query . $group_by_query . $order_by_query);

		$statement->execute();

		$filtered_rows = $statement->rowCount();

		$statement = $conn->prepare($main_query . $group_by_query);

		$statement->execute();

		$total_rows = $statement->rowCount();

		$result = $conn->query($main_query . $search_query . $group_by_query . $order_by_query . $limit_query, PDO::FETCH_ASSOC);

		$data = array();

		foreach($result as $row)
		{
			$sub_array = array();

			$sub_array[] = $row['datePurchased'];

			$sub_array[] = $row['feedName'];

			$sub_array[] = $row['brand'];

			$sub_array[] = $row['startingQuantity'];

			$sub_array[] = $row['inStock'];

			$sub_array[] = $row['reductions'];

			$data[] = $sub_array;
		}

		$output = array(
			"draw"			=>	intval($_POST["draw"]),
			"recordsTotal"	=>	$total_rows,
			"recordsFiltered" => $filtered_rows,
			"data"			=>	$data
		);

		echo json_encode($output);
	}

}
