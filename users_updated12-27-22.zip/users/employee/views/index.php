<?php
    //define variable title to store the page title
    $title ="Employee Dashboard";
    
    //include header file located two folders above view folder 
    include('../../includes/header.php'); 
    
    $employee_ID = $_SESSION["user_ID"];
?>

<!-- content --> 
<div class="container-fluid px-4">
    <h1 class="mt-4"> Employee Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>
    
    <div class="row justify-content-center mt-2">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">
                     Number of Completed <strong>Medication </strong>  Schedules:
                    <span class="fw-bold fs-3">
                    <?php
                        //connect to the database
                        include('../../../config/database_connection.php');

                        //to count how many schedules are completed
                        $sql = "SELECT COUNT(status) as 'total' FROM medication WHERE status = 'completed' AND archive = 'not archived' AND administeredBy = $employee_ID";
                        $stmt = $conn->query($sql);
                        $stmt->execute();
                        print_r($stmt->fetchColumn());

                        // Close connection
                        unset($conn);
                    ?>
                    </span>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="medication_completed.php">View More</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-danger text-white mb-4">
                <div class="card-body">
                    Number of Pending <strong> Medication</strong>  Schedules:
                    <span class="fw-bold fs-3">
                    <?php
                        //connect to the database
                        include('../../../config/database_connection.php');

                        //to count how many schedules are pending
                        $sql = "SELECT COUNT(status) as 'total' FROM medication WHERE status = 'pending' AND archive = 'not archived' AND administeredBy = $employee_ID";
                        $stmt = $conn->query($sql);
                        $stmt->execute();
                        print_r($stmt->fetchColumn());

                        // Close connection
                        unset($conn);
                    ?>
                    </span>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="medication_pending.php">View More</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">
                     Number of Completed <strong> Vaccination</strong>  Schedules:
                    <span class="fw-bold fs-3">
                    <?php
                        //connect to the database
                        include('../../../config/database_connection.php');

                        //to count how many schedules are completed
                        $sql = "SELECT COUNT(status) as 'total' FROM vaccination WHERE status = 'completed' AND archive = 'not archived' AND administeredBy = $employee_ID";
                        $stmt = $conn->query($sql);
                        $stmt->execute();
                        print_r($stmt->fetchColumn());

                        // Close connection
                        unset($conn);
                    ?>
                    </span>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="vaccination_completed.php">View More</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-danger text-white mb-4">
                <div class="card-body">
                    Number of Pending <strong> Vaccination</strong> Schedules:
                    <span class="fw-bold fs-3">
                    <?php
                        //connect to the database
                        include('../../../config/database_connection.php');

                        //to count how many schedules are pending
                        $sql = "SELECT COUNT(status) as 'total' FROM vaccination WHERE status = 'pending' AND archive = 'not archived' AND administeredBy = $employee_ID";
                        $stmt = $conn->query($sql);
                        $stmt->execute();
                        print_r($stmt->fetchColumn());

                        // Close connection
                        unset($conn);
                    ?>
                    </span>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="vaccination_pending.php">View More</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end of content -->

<?php
    //footer
    include('../../includes/footer.php');

    //scripts
    include('../../includes/scripts.php');
?>
