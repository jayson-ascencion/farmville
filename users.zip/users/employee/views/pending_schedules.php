<?php
    //page title
    $title ="Pending Schedules";
    
    //header
    include('../../includes/header.php');

    $title = "Employee Dashboard";
?>

<!-- content --> 
<div class="container-fluid px-4">

    <h1 class="mt-4"> Employee Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">
            <a href="./index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Pending Schedules</li>
    </ol>

    <div class="wrapper">
        <div class="container">
            <div class="row mb-5">
                <div class="p-0">
                    <div class="card shadow-lg">
                        <div class="card-header">
                            <h4 class="p-1">Pending Schedules</h4>
                        </div>

                        <div class="card-body">
                            <div class="table-responsive m-1 border border-light">
                                <?php
                                    // Include config file
                                    include('./query/pending_sched_record.php');
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>        
        </div>
    </div>

</div>
<!-- end of content -->

<?php
    //header
    include('../../includes/footer.php');

    //scripts
    include('../../includes/scripts.php');
?>
