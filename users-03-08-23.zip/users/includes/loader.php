<div class="loader-container">
  <div class="d-flex vw-auto vh-100 d-flex align-content-center flex-wrap justify-content-center">
    <div class="spinner-border text-warning" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
  </div>
</div>
