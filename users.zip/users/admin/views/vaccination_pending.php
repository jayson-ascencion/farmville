<?php
    //page title
    $title ="Pending Schedules";
    
    //header
    include('../../includes/header.php');

    $title = "Employee Dashboard";
?>

<!-- content --> 
<div class="container-fluid px-4">

    <h1 class="mt-4"> Admin Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">
            <a href="./index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active"> Vaccination Schedules</li>
    </ol>

    <div class="wrapper">
        <div class="container">
            <div class="row mb-5">
                <div class="p-0">
                    <div class="card shadow-lg">
                        <div class="card-header">

                            <div class="w-100 d-flex justify-content-between p-2">
                                <div>
                                    <h4 class="pt-2">Pending Vaccination Schedules</h4>
                                </div>

                                <div>
                                    <a href="add_sched_vaccination.php" class="btn btn-primary pt-2">Add Schedule</a>
                                    
                                </div>
                            </div>
                        
                        </div>

                        <div class="card-body">
                            <div class="table-responsive m-1">
                                <?php
                                    // Include config file
                                    include('./query/vaccination_pending_records.php');
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>    
        </div>
    </div>

</div>
<!-- end of content -->

<?php
    //header
    include('../../includes/footer.php');

    //scripts
    include('../../includes/scripts.php');
?>
