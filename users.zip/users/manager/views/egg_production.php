<?php
    //title of the pge
    $title = "Egg Production";

    //header
    include("../../includes/header.php");
?>

<!-- content --> 
<div class="container-fluid px-4">
    <h1 class="mt-4"> Manager Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">
            <a href="./index.php" style="text-decoration: none">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Egg Production</li>
    </ol>

    <div class="wrapper mt-1">
        <div class="container">
            <div class="row mb-5">
                <div class="p-0">
                    <div class="card shadow-lg mb-4">
                        <div class="card-header fw-bold pb-3 fs-5" style="background-color: #FFE7C2;">
                        <div class="p-2">
                            Total Eggs In Stock <span class="fs-6 fw-normal">(trays)</span>: 
                        </div>
                        </div>
                    <div class="row p-3 text-center">
                        <div class="col-sm">
                            <div class="card bg-primary text-white mb-2">
                                <div class="card-header">Extra Small: <span class="fw-bold fs-6">
                                    <?php
                                        //connect to the database
                                        include('../../../config/database_connection.php');

                                        //to count how many schedules are completed
                                        $sql = "SELECT SUM(quantity) as 'total' FROM eggproduction WHERE eggSize = 'XS'";
                                        $stmt = $conn->query($sql);
                                        $stmt->execute();
                                        $total = $stmt->fetchColumn();
                                        if($total > 0){
                                            echo $total;
                                        }else{
                                            echo "0";
                                        }

                                        // Close connection
                                        unset($conn);
                                    ?>
                                </span></div>
                            </div>
                        </div>
                        <div class="col-sm">
                            <div class="card bg-primary text-white mb-2">
                                <div class="card-header">Small: <span class="fw-bold fs-6">
                                    <?php
                                        //connect to the database
                                        include('../../../config/database_connection.php');

                                        //to count how many schedules are completed
                                        $sql = "SELECT SUM(quantity) as 'total' FROM eggproduction WHERE eggSize = 'S'";
                                        $stmt = $conn->query($sql);
                                        $stmt->execute();
                                        $total = $stmt->fetchColumn();
                                        if($total > 0){
                                            echo $total;
                                        }else{
                                            echo "0";
                                        }

                                        // Close connection
                                        unset($conn);
                                    ?>
                                </span></div>
                            </div>
                        </div>
                        <div class="col-sm">
                            <div class="card bg-warning text-white mb-2">
                                <div class="card-header">Medium: <span class="fw-bold fs-6">
                                    <?php
                                        //connect to the database
                                        include('../../../config/database_connection.php');

                                        //to count how many schedules are completed
                                        $sql = "SELECT SUM(quantity) as 'total' FROM eggproduction WHERE eggSize = 'M'";
                                        $stmt = $conn->query($sql);
                                        $stmt->execute();
                                        $total = $stmt->fetchColumn();
                                        if($total > 0){
                                            echo $total;
                                        }else{
                                            echo "0";
                                        }

                                        // Close connection
                                        unset($conn);
                                    ?>
                                </span></div>
                            </div>
                        </div>
                        <div class="col-sm">
                            <div class="card bg-success text-white mb-2">
                                <div class="card-header">Large: <span class="fw-bold fs-6">
                                    <?php
                                        //connect to the database
                                        include('../../../config/database_connection.php');

                                        //to count how many schedules are completed
                                        $sql = "SELECT SUM(quantity) as 'total' FROM eggproduction WHERE eggSize = 'L'";
                                        $stmt = $conn->query($sql);
                                        $stmt->execute();
                                        $total = $stmt->fetchColumn();
                                        if($total > 0){
                                            echo $total;
                                        }else{
                                            echo "0";
                                        }

                                        // Close connectionprint_r($stmt->fetchColumn());
                                        unset($conn);
                                    ?>
                                </span></div>
                            </div>
                        </div>
                        <div class="col-sm">
                            <div class="card bg-danger text-white mb-2">
                                <div class="card-header">Extra Large: <span class="fw-bold fs-6">
                                    <?php
                                        //connect to the database
                                        include('../../../config/database_connection.php');

                                        //to count how many schedules are completed
                                        $sql = "SELECT SUM(quantity) as 'total' FROM eggproduction WHERE eggSize = 'XL'";
                                        $stmt = $conn->query($sql);
                                        $stmt->execute();
                                        $total = $stmt->fetchColumn();
                                        if($total > 0){
                                            echo $total;
                                        }else{
                                            echo "0";
                                        }

                                        // Close connection
                                        unset($conn);
                                    ?>
                                </span></div>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="card  shadow-lg"> 
                        <div class="card-header" style="background-color: #FFE7C2;">

                            <div class="w-100 d-flex justify-content-between p-2">
                                <div>
                                    <h4 class="pt-2 fw-bold fs-5">Egg Production</h4>
                                </div>

                                <div>
                                    <a href="add_egg_form.php" class="btn btn-primary pt-2">Add Egg</a>
                                </div>
                            </div>
                        
                        </div>

                        <div class="card-body">
                            <div class="table-responsive m-1">
                                <?php
                                    //this will display all the chicken production data
                                    include('./query/egg_production_records.php');
                                ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>        
        </div>
    </div> 
<?php
    include("../../includes/footer.php");
    
    include("../../includes/scripts.php");
?>