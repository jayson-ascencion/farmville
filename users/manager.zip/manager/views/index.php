<?php
    $title = "Manager Dashboard";
    //header
    include('../../includes/header.php');

    //database connection
    include('../../../config/database_connection.php');
?>

<!-- content --> 
<div class="container-fluid px-4">
    <h1 class="mt-4"> Manager Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active" style="text-decoration: none">Dashboard</li>
    </ol>
    <div class="row">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4">
                <div class="card-body">Primary Card</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white mb-4">
                <div class="card-body">Warning Card</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">Success Card</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-danger text-white mb-4">
                <div class="card-body">Danger Card</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
    </div>
    <!-- <div class="row">
      <div class="chartMenu">
        <p>
          HAHAHAHA
        </p>
      </div>
      <div class="chartCard">
        <div class="chartBox">
          <canvas id="myChart"></canvas>
          <button onclick="timeFrame(this)" value="year">Day</button>
          <button onclick="timeFrame(this)" value="week">Week</button>
          <button onclick="timeFrame(this)" value="month">Month</button>
        </div>
      </div>
    </div> -->

</div>
<!-- end of content -->

<?php
    //header
    include('../../includes/footer.php'); 
    
    //scripts
    include('../../includes/scripts.php');
?>
<!-- 
<script>
  const date = Date.parseo json_encode($dateArray); ?>);
  const quantity = echo json_encode($quantityArray); ?>;
  const week = [
    { x: date, y: quantity},
    // { x: Date.parse('2019 00:00:00 GMT+0800'), y: 8},
    // { x: Date.parse('2020 00:00:00 GMT+0800'), y: 16},
    // { x: Date.parse('2021 00:00:00 GMT+0800'), y: 5},
    // { x: Date.parse('2022 00:00:00 GMT+0800'), y: 1},
  ];

  const month = [
    { x: Date.parse('2022-08-01 00:00:00 GMT+0800'), y: 18},
    { x: Date.parse('2022-09-01 00:00:00 GMT+0800'), y: 8},
    { x: Date.parse('2022-10-01 00:00:00 GMT+0800'), y: 16},
    { x: Date.parse('2022-11-01 00:00:00 GMT+0800'), y: 5},
    { x: Date.parse('2022-12-01 00:00:00 GMT+0800'), y: 1},
  ];

  // setup echo json_encode($quantityArray); ?>,
  const data = {
    // labels: ['MON','TUE','WED','THU','FRI'],
    datasets: [{
      label: 'Reductions',
      data: week,
      backgroundColor: [
        'rgba(255, 26, 104, 0.2)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)',
        'rgba(153, 102, 255, 0.2)',
        'rgba(255, 159, 64, 0.2)',
        'rgba(255, 25, 25, 0.2)'
      ],
      borderColor: [
        'rgba(255, 26, 104, 1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)',
        'rgba(153, 102, 255, 1)',
        'rgba(255, 159, 64, 1)',
        'rgba(0, 0, 0, 1)'
      ],
      borderWidth: 1
    }]
  };

  // config 
  const config = {
    type: 'bar',
    data,
    options: {
      plugins: {
        tooltip: {
          callbacks: {
            title: context => {
              console.log(context)
              const d = new Date(context[0].parsed.x);
              const formattedDate = d.toLocaleDateString([],{
                month: 'short',
                day: 'numeric',
                year: 'numeric'
              })
              return formattedDate;
            }
          }
        }
      },
      scales: {
        x: {
          type: 'time',
          time: {
            unit: 'year'
          }
        },
        y: {
          beginAtZero: true
        }
      }
    },
  };

  // render init block
  const myChart = new Chart(
    document.getElementById('myChart'),
    config
  );

  function timeFrame(period){
    console.log(period.value);

    if(period.value == 'year'){
      myChart.config.options.scales.x.time.unit = period.value;
      myChart.config.data.datasets[0].data = year;
    }
    if(period.value == 'week'){
      myChart.config.options.scales.x.time.unit = period.value;
      myChart.config.data.datasets[0].data = week;
    }
    if(period.value == 'month'){
      myChart.config.options.scales.x.time.unit = period.value;
      myChart.config.data.datasets[0].data = month;
    }

    myChart.update();
  }
</script> -->